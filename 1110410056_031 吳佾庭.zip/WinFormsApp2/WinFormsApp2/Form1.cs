using System.Text.RegularExpressions;

namespace WinFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string input = textBox1.Text;
            List<int> indices = new List<int>();

            Match xMatch = Regex.Match(input, @"x=""([^""]+)""");
            string x = xMatch.Groups[1].Value;
            if (Regex.IsMatch(x, @"^[a-z]$"))
            {
                MatchCollection matches = Regex.Matches(input, @"\[(.*?)\]");
                string extractedString = matches[0].Groups[1].Value;                                              
                string[] words = extractedString.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

                if(1 <= words.Length && words.Length <= 50)
                {
                    for (int i=0; i<words.Length; i++)
                    {
                        if (1 <= words[i].Length && words[i].Length <= 50)
                        {
                            if (words[i].Contains(x))
                            {

                                indices.Add(i);

                            }
               
                        }
                        else
                        {
                            MessageBox.Show($"words[{i}] ���ŦX�W�d.");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("words���� ���ŦX�W�d.");
                }
            }
            else
            {
                MessageBox.Show("x ���ŦX�W�d.");
            }


            textBox2.Text = "[" + string.Join(",", indices) + "]";
        }
    }
}
